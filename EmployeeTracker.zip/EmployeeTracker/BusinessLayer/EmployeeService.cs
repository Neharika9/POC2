﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using EmployeeTracker.Models;
using EmployeeTracker.Repositories;

namespace EmployeeTracker.BusinessLayer
{
    public class EmployeeService
    {
        public EmployeeInfoRepository _employeeInfoRepository;

        public static List<Employee> _empList;  //complete list of employees
       

        public EmployeeService()
        {
            _employeeInfoRepository = new EmployeeInfoRepository();
            
        }


        /// <summary>
        /// Gets all orders with names of employee.
        /// </summary>
        /// <returns></returns>
        public IEnumerable<Employee> Get()
        {
            if (_empList == null )
            {
                _empList = _employeeInfoRepository.Get().ToList();
               
            }
            return _empList;
        }
    }
}